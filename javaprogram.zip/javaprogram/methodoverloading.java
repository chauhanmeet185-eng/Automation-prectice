class methodoverloading
{
	void add(int a, int b)
	{
		System.out.println("add = " + (a + b));
	}
	void add(int a, int b, int c)
	{
		System.out.println("add = " + (a + b + c));
	}
	/*void sub(double a, double b)
	{
		System.out.println("sub = " + (a * b));
	}*/
	/*void add(int a, double b)
	{
		System.out.println("value of int and double = " + (a + b));
	}
	void add(double a, int b)
	{
		System.out.println("vlaue of double and int = " + (a + b));
	}*/
	
	public static void main(String args[])
	{
		methodoverloading m = new methodoverloading();
		m.add(4,4);
		m.add(4,4,4);
		//m.sub(4.5,4.5);
		//m.add(4,5.2);
		//m.add(5.2,4);
	}
}