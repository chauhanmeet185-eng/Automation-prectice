class constuctorex
{
	
	// no arg should diff
    constuctorex(int a)
	{
		System.out.println("in constuctor = "+a);
	}

// type arg should diff	
	constuctorex(String b,int a)
	{
		System.out.println("in string and int constuctor = "+ b + "int = " +a);	
	}
    
// order should diff
    constuctorex(int b,String a)
	{
		System.out.println("in int and string constuctor = "+ b + " string = " +a);	
	}
   public static void main(String str[])
	{
		constuctorex c = new constuctorex("hello ",89);
		new constuctorex(35,"stad");
		new constuctorex(95);
	}
}