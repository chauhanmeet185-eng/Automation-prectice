class simpledemo
{
	int a=10;
	byte b=40;
	short s=500;
	long l=800L;
	float f=4.5f;
	double d=54;
	boolean bool=true;
	char c='M';
	String name="hello all";
	
	public static void main(String args[])
	{
		simpledemo de1 = new simpledemo();
		System.out.println("int value :" + de1.a);
		System.out.println("byte value :" + de1.b);
		System.out.println("short value :" + de1.s);
		System.out.println("long value :" + de1.l);
		System.out.println("float value :" + de1.f);
		System.out.println("double value :" + de1.d);
		System.out.println("boolean value :" + de1.bool);
		System.out.println("char value :" + de1.c);
		System.out.println("String value :" + de1.name);	
	}
}