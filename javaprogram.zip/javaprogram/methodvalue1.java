class methodvalue1
{
	int a = 50;
	static int b = 80;

	void nonstaticvar()
	{
		System.out.println("Non static variable");
	}
	void staticvar()
	{
		System.out.println("Static variable");
	}
	
	public static void main(String args[])
	{
		methodvalue1 m = new methodvalue1();
		System.out.println("non static variable=" +m.a);
		System.out.println("static variable=" +m.b);
	}
}