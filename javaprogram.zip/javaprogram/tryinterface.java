interface me
{
	void show();
	void display();
}
class tryinterface implements me
{
	public void show()
	{
		System.out.println("print show method");
	}
	public void display()
	{
		System.out.println("print display method");
	}
	public static void main(String args[])
	{
		tryinterface t = new tryinterface();
		t.show();
		t.display();
	}
}