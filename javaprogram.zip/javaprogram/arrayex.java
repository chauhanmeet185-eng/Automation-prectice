class arrayex
{
	public static void main(String args[])
	{
		int a[] = {4,12,20,54,80};
		for(int i=0; i<a.length; i++)
		{
			System.out.println(a[i]);
		}
	}
}