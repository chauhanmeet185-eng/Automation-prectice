class checkedexception
{
	public static void main(String str[])
	{
    try
	{
      int a=10/0;
	  System.out.println("value of a = "+a);
	}
	catch(ArithmeticException e)
	{
	  System.out.println("error handeling");
	}
    System.out.println("after error handel");
	}
}