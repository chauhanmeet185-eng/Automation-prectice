class vowelconsonant 
{
    String str;
    vowelconsonant(String s) 
	{
        str=s.toLowerCase();
        count();
    }
    void count() 
	{
        int vowel=0, consonant=0;
        for (int i=0; i<str.length(); i++) 
		{
            char ch=str.charAt(i);
            if (ch>='a' && ch<='z') 
			{
                if (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
				{
                    vowel++;
				}
                else
                    consonant++;
            }
        }
        System.out.println("vowels: "+vowel);
        System.out.println("consonants: "+consonant);
    }
    public static void main(String args[]) 
	{
        new vowelconsonant("Welcome To Java Program");
    }
}