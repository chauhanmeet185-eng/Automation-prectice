class typesofmethod
{
	int a = 50;
	int b = 25;
	
	void non()
	{
		System.out.println("non static method");
	}
	static void ex()
	{
		System.out.println("static method");
	}
	
	public static void main(String args[])
	{
		typesofmethod m = new typesofmethod();
		System.out.println("Value of a= "+m.a);
		System.out.println("Value of b= "+m.b);
	}
}