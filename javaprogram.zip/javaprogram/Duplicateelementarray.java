class Duplicateelementarray
{
    public static void main(String args[])
    {
        int a[] = {4, 24, 37, 24, 4, 49};
        for(int i=0; i<a.length; i++)
        {
            for(int j=i+1; j<a.length; j++)
            {
                if(a[i] == a[j])
                {
                    System.out.println("duplicate values: "+a[i]);
                }
            }
        }
    }
}