class twoDarray
{
	public static void main(String args[])
	{
		int a[][] = { {12,15,20},{90,95,99} };
		for(int i=0; i<2; i++)
		{
			for(int j=0; j<3; j++)
			{
				System.out.print(" " +a[i][j]);
			}
		System.out.println(" ");
		}
	}
}