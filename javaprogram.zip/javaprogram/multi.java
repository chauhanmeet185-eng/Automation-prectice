class multi
{
	int a=4;
	int b=5;
	void multi()
	{
		int c = a * b;
		System.out.println("result: " +c);
	}
	public static void main(String args[])
	{
		multi m = new multi();
		m.multi();
	}
}