import java.util.*;
class Arraylistdemo
{
	public static void main(String str[])
	{
		List<String> list = new ArrayList<String>();
		list.add("JAVA");
		list.add("PHP");
		list.add(".net");
		list.add("C#");
		System.out.println(list);
  
		//For each loop
		for(String s : list)
		{
			if(s.equals(".net"))
			{
				System.out.println(s);
			}
		}
	  
		// using iterator
		Iterator itr = list.iterator();
		while(itr.hasNext())
		{
			String s1 = (String)itr.next();
			if(s1.equals("PHP"))
			{
				System.out.println(s1);
			}
		}
		
		// using listIterator (Forward & Backward)
		System.out.println("\nUsing ListIterator Forward:");
		ListIterator<String> li = list.listIterator();
		while(li.hasNext())
		{
			System.out.println(li.next());
		}
		System.out.println("\nUsing ListIterator Backward:");
		while(li.hasPrevious())
		{
			System.out.println(li.previous());
		}
	}
}