class exceptionex
{
	public static void main(String str[])
	{
		try
		{
		   int a=10/0;
		   System.out.println("value of a = "+a);
		   int b[] = new int[5];
		   b[6]=66;
		}
		/* 
		catch(Exception en)
		{
			System.out.println("both handel");
		} */
		finally
		{
			System.out.println("after error handel");
		}
	}
}