class calc 
{
    public static void main(String args[])
	{
        int a = 12, b = 6;
        String str = "div";

        switch (str) 
		{
            case "add":
                System.out.println(a + b);
                break;
            case "sub":
                System.out.println(a - b);
                break;
            case "mul":
                System.out.println(a * b);
                break;
            case "div":
                System.out.println(a / b);
                break;
			default:
				System.out.println("invalid value");
        }
    }
}