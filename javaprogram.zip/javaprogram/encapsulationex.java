class encapsulationex
{
	private int roll;
	private String name;
   
	// setter
	public void setroll(int roll)
	{
	   //roll=r;
	   this.roll=roll;
	   // roll=101;
	}

	// getter
	public int getroll()
	{
	  return this.roll;
	}

    public void setname(String name)
	{
		this.name=name;
	}
	
	public String getname()
	{
	   return this.name;   
	}
}

class bankex
{
    public static void main(String str[])
	{	
		encapsulationex e1 = new encapsulationex();
		encapsulationex e2 = new encapsulationex();
		e1.setroll(101);
		e1.setname("Kiran");
		System.out.println("roll = "+e1.getroll());
		System.out.println("name = "+e1.getname());
		
		e2.setroll(102);
		e2.setname("Kiran");
		System.out.println("roll = "+e2.getroll());
		System.out.println("name = "+e2.getname());	
	}		
}