class defaultconstructor 
{
    int num;
    defaultconstructor() 
	{
        num = 2002;
        System.out.println("value of num = " + num);
    }
    public static void main(String args[]) 
	{
        new defaultconstructor();
    }
}