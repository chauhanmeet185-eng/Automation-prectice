class stringex
{
	public static void main(String str[])
	{
		String s = "Amit is student";
		String s1 = "AMIT IS STUDENT";
		String s2 = new String("Amit is good student");
		String s3 = "Hello ";
		String s4 = "       MEET       ";
		
		/*if(s.equals(s1))
		{
			System.out.print("equals");
		}*/
		if(s.equalsIgnoreCase(s1))
		{
			System.out.println("equals");
		}
		else
		{
			System.out.println("not equals");
		}
		//concat
		System.out.println("concat = "+s3.concat(s));
		
		//compareto
		System.out.println("compareTo = "+s1.compareTo(s));
		
		//upper
		System.out.println("Uppercase = "+s3.toUpperCase());
		
		//lower
		System.out.println("Lowercase = "+s1.toLowerCase());
		
		//length - show the length of characters
		System.out.println("length = "+s.length());
   
		//startswith - apel word thi start thay toh true output ma ave baki false ave
		System.out.println("starts with = "+s.startsWith("am"));
		
		//endswith - apel word thi end thay to true ave baki false ave
		System.out.println("ends with = "+s.endsWith("t"));
	
		//charAt - anathi 2nd position ma je word hoy te character ma show kare
		System.out.println("charAt = "+s.charAt(2));
	 
		// indexof - anathi word ni je position hoy te number ma show kare
		System.out.println("indexof = "+s.indexOf("i"));
	 
		//trim - remove the space
		System.out.println("trim = "+s4.trim());
		System.out.println("s4= "+s4);
	   
		//split - sentence ma je jagyaye sapce ave nyathi alag line ma print kare etale split kari nakhe
		String a[]=s2.split(" ");
	   
		for(String s5 : a)
		{
		    System.out.println("split string = "+s5);
		}
	   
		//substring - number apel hoy ye je character thi start thay ena pachhi nu badhu print kare
		System.out.println("part-1 = "+s.substring(2));
	    System.out.println("part-2 = "+s.substring(2,12));
	}
}
/*
== : add
equals : value
equalsIgnoreCase : case sensitivity ignore
compareTo : value key different
concat : two value marge
*/