class Vehicle
{
    void run()
    {
        System.out.println("vehicle is running");
    }
}

class Bike extends Vehicle
{
    void run()
    {
        System.out.println("bike is running safely");
    }

    public static void main(String[] args)
    {
        Bike b = new Bike();
        b.run();
		Vehicle v = new Vehicle();
		v.run();
    }
}