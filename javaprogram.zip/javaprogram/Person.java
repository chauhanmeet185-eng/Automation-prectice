class Person 
{
    String name;
    int age;
	
    Person(String n, int a) 
	{
        name = n;
        age = a;
    }
    void displayPerson() 
	{
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}
class Student extends Person 
{
    int rollNo;

    Student(String n, int a, int r) 
	{
        super(n, a);   
        rollNo = r;
    }
    void displayStudent() 
	{
        displayPerson();
        System.out.println("Roll No: " + rollNo);
    }
    public static void main(String args[]) 
	{
        Student s = new Student("Meet", 23, 4);
        s.displayStudent();
    }
}