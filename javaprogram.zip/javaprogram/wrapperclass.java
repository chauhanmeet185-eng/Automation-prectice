class wrapperclass
{
	public static void main(String str[])
	{
		int a=45; // premitive data type
		Integer o = a;
		System.out.println(o);
		Integer obj = 66;
		int b = obj;
		System.out.println(b);
	}
}