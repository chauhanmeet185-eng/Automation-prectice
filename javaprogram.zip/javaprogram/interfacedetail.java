interface m
{
	void show();
}
interface n
{
	void display();
}
class interfacedetail implements m,n
{
	public void show()
	{
		System.out.println("show interface to m");
	}
	public void display()
	{
		System.out.println("show interface to n");
	}
	public static void main(String args[])
	{
		interfacedetail i = new interfacedetail();
		i.show();
		i.display();
	}
}