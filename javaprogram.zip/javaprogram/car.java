abstract class vehical
{
	abstract void start();
	void  fueltype()
	{
		System.out.println("fuel type is petrol");
	}
}
class car extends vehical
{
	void start()
	{
		System.out.println("car starts with the key");
	}
	public static void main(String args[])
	{
		car c = new car();
		c.start();
		c.fueltype();
	}
}