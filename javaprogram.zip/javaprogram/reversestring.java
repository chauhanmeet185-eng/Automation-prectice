class reversestring 
{
    reversestring(String str) 
	{
        String rev="";

        for (int i=str.length()-1; i>=0; i--) 
		{
            rev=rev+str.charAt(i);
        }
        System.out.println("reverse: " + rev);
    }
    public static void main(String args[]) 
	{
        new reversestring("Meet");
    }
}