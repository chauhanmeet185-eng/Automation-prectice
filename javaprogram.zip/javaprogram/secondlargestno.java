class secondlargestno
{
    public static void main(String args[])
    {
        int a[] = {4, 21, 98, 101, 120};
        int largest = a[0];
        int secondlargest = a[0];

        for(int i=1; i<a.length; i++)
        {
            if(a[i]>largest)
            {
                secondlargest = largest;
                largest = a[i];
            }
            else if(a[i]<largest && a[i]>secondlargest)
            {
                secondlargest = a[i];
            }
        }
        System.out.println("second largest no = " +secondlargest);
    }
}