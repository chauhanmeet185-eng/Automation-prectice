class positiveno
{
	public static void main(String args[])
	{
		int num=-7;
		if(num > 0)
		{
			System.out.println("positive no");
		}
		else
		{
			System.out.println("not a positive no");
		}
	}
}