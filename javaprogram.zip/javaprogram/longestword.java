class longestword 
{
    longestword(String str) 
	{
        String word="";
        String longest="";
        for (int i=0; i<str.length(); i++) 
		{
            if (str.charAt(i)!=' ') 
			{
                word=word+str.charAt(i);
            } 
			else 
			{
                if (word.length()>longest.length())
                    longest=word;
                word="";
            }
        }
        if (word.length()>longest.length())
            longest=word;
        System.out.println("longest word: "+longest);
    }
    public static void main(String args[]) {
        new longestword("Java is very powerful Programming language");
    }
}