class differentclass
{
	
	public static void main(String args[])
	{
		typesofmethod n = new typesofmethod();
		System.out.println(" Value of a= "+n.a);
		System.out.println(" Value of b= "+n.b);
	}
}