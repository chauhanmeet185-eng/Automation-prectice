import java.io.*;
// import java.io.FileOutputStream

public class filewritedemo
{
	public static void main(String str[])throws IOException
	{
		FileOutputStream f = new FileOutputStream("E:\\javaprogram\\basic\\myfirst.txt");
		// f.write(101);
		String s = "hello how are you";
		byte b[] = s.getBytes();
		f.write(b);	
		System.out.println("written successfully");
	}
}