import java.io.*;
public class filecreatedemo
{
	public static void main(String str[])throws IOException
	{
		File f = new File("E:\\javaprogram\\basic\\myfirst.txt");
		if(f.createNewFile())
		{
			System.out.println("File created succesfully");
		}
		else
		{
			System.out.println("File alredy exists");
		}
	}
}