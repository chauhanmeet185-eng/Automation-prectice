class largesttwono
{
	public static void main(String args[])
	{
		int a = 44;
		int b = 104;
	
		if(a > b)
		{
			System.out.println("a is largest number");
		}
		else 
		{
			System.out.println("b is largest number");
		}
	}
}