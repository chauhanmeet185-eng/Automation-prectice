/*class grandparent
{
   int d=60;
   void test()
   {
		System.out.println("in grandparent");
   }
}*/

class parent 
{
   int a=10;
   void show()
   {
		System.out.println("in parent");
   }
}

class child extends parent
{
   int b=20;
   void display()
   {	   
		System.out.println("in child");
   }
}

class child2 extends parent
{
   int f=90;
   void abc()
   {
		System.out.println("in 2ndchild"); 
   }
}

class inheritancex
{
    public static void main(String str[])
	{
		//parent p = new parent();
		//p.show();
	
		child c = new child();
		c.display();
		c.show();
		
		child2 c2 = new child2();
		c2.abc();
		c2.show();

		System.out.println("value of a = "+c.a);
		System.out.println("value of b = "+c.b);
	
		System.out.println("value of a = "+c2.a);
		System.out.println("value of f = "+c2.f); 
		//System.out.println("value of d = "+c.d);
		//System.out.println("value of f= "+c.f);
	}
}