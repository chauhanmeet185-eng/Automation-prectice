class triangle 
{
    int a, b, c;
    triangle(int x, int y, int z) 
	{
        a = x;
        b = y;
        c = z;
    
        int perimeter = a + b + c;
        double s = perimeter / 2.0;
        double area = Math.sqrt(s*(s-a)*(s-b)*(s-c));

        System.out.println("perimeter of triangle = " +perimeter);
        System.out.println("area of triangle = " +area);
    }

    public static void main(String args[]) 
	{
        new triangle(3, 4, 5);
    }
}