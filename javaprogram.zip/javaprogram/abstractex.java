abstract class abstractex
{
	static int a=10;
	int b=20;

	abstract void show(String s);
	void display()
	{
		System.out.println("in display"); 
	}
	static void test()
	{
		System.out.println("in test"); 
	}
	abstractex()
	{	
		System.out.println("in constructor");
	}
	/*public static void main(String str[])
	{	 
		test();
		//abstractex a1 = new abstractex();
		//a1.display();
		//a1.show();
	}*/
}
class abstractimpli extends abstractex
{
	void show(String s)
	{
		System.out.println("in show = "+s);
	}
	public static void main(String str[])
	{
		abstractimpli a1 = new abstractimpli();
		a1.show("hello");
	}
}	