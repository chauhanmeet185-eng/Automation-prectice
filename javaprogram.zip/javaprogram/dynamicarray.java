class dynamicarray
{
	public static void main(String args[])
	{
		int a[] = new int[4];
		for(int i=0; i<a.length; i++)
		{
			a[i] = 4*i +4;
			System.out.println(a[i]);
		}
	}
}