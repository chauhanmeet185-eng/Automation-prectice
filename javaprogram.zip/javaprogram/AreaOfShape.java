class AreaOfShape
{
	void area(double r)
	{
		double result = 3.14 * r * r;
		System.out.println("area of circle:" + result);
	}
	void area(int a)
	{
		int result = a * a;
		System.out.println("area of square:" + result);
	}
	public static void main(String args[])
	{
		AreaOfShape n = new AreaOfShape();
		n.area(4.0);
		n.area(4);
	}
}