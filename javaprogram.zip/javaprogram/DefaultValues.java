class DefaultValues {
    byte b;
    short s;
    int i;
    long l;
    float f;
    double d;
    char c;
    boolean bool;
    String str;

    public static void main(String args[]) {
	
		DefaultValues obj = new DefaultValues();
        System.out.println("byte value: " + obj.b);
        System.out.println("short value: " + obj.s);
        System.out.println("int value: " + obj.i);
        System.out.println("long value: " + obj.l);
        System.out.println("float value: " + obj.f);
        System.out.println("double value: " + obj.d);
        System.out.println("char value: " + obj.c);
        System.out.println("boolean value: " + obj.bool);
        System.out.println("String value: " + obj.str);
    }
}