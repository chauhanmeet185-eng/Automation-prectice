import java.io.*;
class throwsex
{
	public static void main(String str[])
	{
		try
		{
			throw new IOException();
		}
		catch(IOException ie)
		{
			System.out.println("error handel");
		}
		System.out.println("after error hande");
	}
}