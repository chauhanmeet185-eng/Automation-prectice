class sumofrows
{
    public static void main(String args[])
    {
        int a[][] = { {10, 45, 31}, {74, 85, 66}, {47, 18, 79} };

        for(int i=0; i<a.length; i++)
        {
            int sum = 0;
            for(int j=0; j<a[i].length; j++)
            {
                sum = sum+a[i][j];
            }
            System.out.println(sum);
        }
    }
}